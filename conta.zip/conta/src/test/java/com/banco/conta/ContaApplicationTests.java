package com.banco.conta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContaApplicationTests {

	@Test
	void contextLoads() {
	}

}
